<?php
include 'session.inc';

class Messages extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
		$this->load->helper(array('form', 'url'));
    	$this->load->helper('url');
		$this->load->database();
    }
    
    function index()
    {
    }
	
	function go_messages($type, $error = '')
	{
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$data = array('msg_badge' => $array['count'], 'active' => $type);
		$this->load->view('header', $data);

		$this->load->model('message_model');
		if ($type == "inbox") {
			$result = $this->message_model->getInbox($_SESSION['id'], $array);
		} else {
			$result = $this->message_model->getSent($_SESSION['id'], $array);
		}
		$data = array('error' => $error, 'data' => $array, 'type' => $type);

		$this->load->view($type.'_messages', $data);

	}
	function fetch_message()
	{
		$flag = FALSE;
		if ($_REQUEST['type'] == 'inbox') {
			$flag = TRUE;
		}
		$this->load->model('message_model');
		$result = $this->message_model->fetch_messageById($_REQUEST['id'], $flag, $array);
		
		if ($result == 200) {
			$error = "";
		} else {
			$error = "Invalid Message";
		}
		$data = array('data' => $array, 'error' => $error);
		echo json_encode($data);
	}
	function reply_message($page_type, $id, $message_type, $error = "")
	{
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$data = array('msg_badge' => $array['count'], 'active' => 'compose');
		$this->load->view('header', $data);

		$msgInfo = array('id' => '', 'sender_id' => -1, 'service_id' => '', 'concern_id' => '', 'content' => '');
		if ($id != '0') {
			$this->load->model('message_model');
			$result = $this->message_model->fetch_messageById($id, FALSE, $msgInfo);
		}
		$this->load->model('user_model');
		$result = $this->user_model->get_Allmembers($_SESSION['id'], $_SESSION['type'], $_SESSION['country_code'], $u_array);
		$this->load->model('service_model');
		$result = $this->service_model->get_AllSubjects($_SESSION['type'], $_SESSION['id'], $s_array);
		$this->load->model('message_model');
		$result = $this->message_model->get_AllConcerns($c_array);
		$data = array('id' => $id, 'error' => $error, 'user_array' => $u_array , 'msg_array' => $msgInfo, 'service_array' => $s_array, 'concern_array' => $c_array, 'page_type' => $page_type, 'message_type' => $message_type);
		$this->load->view('new_message', $data);
	}
	function delete_message($id, $type)
	{
		$this->load->model('user_model');
		$result = $this->user_model->delete_item('tbl_message', $id);
		if ($result != 200) {
			$error = "Invalid category";
		} else {
			$error = "Successfully deleted";
		}
		$this->go_messages($type, $error);
	}

	function send_message()
	{
		$result = 400;
		$page_type = $_REQUEST['page_type'];
		$message_type = $_REQUEST['message_type'];
		$id = $_REQUEST['id'];
		$sender_id = $_SESSION['id'];
		$service_id = trim($_REQUEST['subject']);
		$content = trim($_REQUEST['content']);
		$concern_id = trim($_REQUEST['concern_id']);
		$timestamp = time();
		if ($service_id == '' || $concern_id == '' || $content == '' || !isset($_REQUEST['receiver'])) {
			$error = 'Please fill in empty fields.';
		}  else if (strlen($content) > 320) {
			$error = 'Content contains more than 320 characters.';
		} else {
			$receiver_arr = $_REQUEST['receiver'];
			$this->load->model('message_model');
			$result = $this->message_model->add_message($sender_id, $receiver_arr, $service_id, $content ,$concern_id, $timestamp);
			$error = "Successfully sent";
		}
		if ($result != 200) {
			$this->reply_message($page_type, $id, $message_type, $error);
		} else {			
			$this->go_messages('sent', $error);
		}

		$subject = $this->message_model->getServicename($service_id);
		$message = array('sender' => $_SESSION['username'], 'type' => $message_type, 'subject' => $subject, 'content' => $content);
		$result = $this->message_model->getTokenArray($receiver_arr, $token_array);
		for ($i=0; $i < count($token_array); $i++) { 
				$this->push_android('message', $token_array[$i], $_SESSION['username'], $content, 0, $message);
		}
	}	

	function push_android($type, $token, $title, $detail, $badge, $data = '')
	{
		$this->load->library('ci_pusher');
		$pusher = $this->ci_pusher->get_pusher();
		$result = $pusher->notify(
		  array($token),
		  array(
		    'gcm' => array(
		      'notification' => array(
		        'title' => $title,
		        'body' => $detail,
		        'icon' => 'androidlogo',
		        'sound' => 'default',
		      ),
		      'data' => array(
		      	'data' => $data,
		      		// 'badge' => intval($badge),
			      	// 'title' => $message),
		      	'type' => $type,
		      ),
		    ),
		    'webhook_url' => 'http://requestb.in/y0xssw70',
		    'webhook_level' => 'INFO',
		  )
		);
	}

	
}
?>