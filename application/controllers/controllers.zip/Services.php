<?php
include 'session.inc';

class Services extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
		$this->load->helper(array('form', 'url'));
    	$this->load->helper('url');
		$this->load->database();
    }
    
    function index()
    {
   //  	if (!isset($_SESSION)) {
			// $this->load->view('login', array('error' => 'Please try to login!'));
			// return;
   //  	}
    }
	function go_invoices($error = '')
	{	
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$this->load->model('service_model');
		$result = $this->service_model->checkFeaturedServices();
		$data = array('msg_badge' => $array['count'], 'active' => 'invoices');
		$this->load->view('header', $data);
		$this->load->model('user_model');

		$this->load->model('admin_model');
		$result = $this->admin_model->get_admin_cost($cost);
		$this->load->model('service_model');
		$result = $this->service_model->get_invoices($_SESSION['id'], $array);
		$data = array('error' => $error, 'data' => $array, 'cost' => $cost);
		$this->load->view('invoices', $data);
	}
	function set_cost()
	{
		if ($_REQUEST['cost'] == 0) {
			$this->go_invoices('Please set the daily publication cost');
			return;
		}
		$this->load->model('admin_model');
		$result = $this->admin_model->set_admin_cost($_REQUEST['cost']);
		$this->go_invoices('Successfully saved!');
	}
	function go_services($featured, $day = 'all', $error = '')
	{	
		if ($featured == 0) {
			$title = "All services";
		} else {
			$title = "Featured services";
		}
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$this->load->model('service_model');
		$result = $this->service_model->checkFeaturedServices();
		$data = array('msg_badge' => $array['count'], 'active' => 'services'.$featured);
		$this->load->view('header', $data);
		$this->load->model('user_model');

		if ($_SESSION['type'] == 'admin') {
			$id = 0;
		} else {
			$id = $_SESSION['id'];
		}
		$array = $this->user_model->get_servicesById_Featured_Day($id, $featured, $day);
		$data = array('error' => $error, 'data' => $array, 'title' => $title, 'featured' => $featured, 'day' => $day);
		$this->load->view('services', $data);
	}
	function go_services_statistics($id, $featured, $day = 'all')
	{	
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$data = array('msg_badge' => $array['count'], 'active' => '');
		$this->load->view('header', $data);
		$this->load->model('user_model');
		$array = $this->user_model->get_servicesById_Featured_Day($id, $featured, $day);
		$result = $this->user_model->get_userById($id, $user_array);
		$data = array('data' => $array, 'featured' => $featured, 'day' => $day, 'name' => $user_array['username']);
		$this->load->view('services_statistics', $data);
	}
	function get_serviceById()
	{
		$this->load->model('service_model');
		$result = $this->service_model->get_serviceById($_REQUEST['id'], $array);
		
		if ($result == 200) {
			$error = "";
		} else {
			$error = "Invalid Service";
		}
		$data = array('data' => $array, 'error' => $error);
		echo json_encode($data);
	}
	function edit_service($page_type, $id, $featured, $error = '')
	{
		$active = 'services'.$featured;
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$data = array('msg_badge' => $array['count'], 'active' => $active);
		$this->load->view('header', $data);
		$this->load->model('admin_model');
		$result = $this->admin_model->get_admin_cost($cost);
		$array = array('id' => '', 'name' => '', 'big_category_id' => '', 'sub_category_id' => '', 'image' => '', 'code' => '', 'url' => '', 'cost_d' => '', 'cost_w' => '',
		 'cost_m' => '', 'detail' => '', 'creator' => $_SESSION['username'], 'provider_id' => '', 'type' => 'public', 'start_time' => '', 'end_time' => '', 'cost' => $cost);
		if ($id != '0') {
			$this->load->model('service_model');
			$result = $this->service_model->get_ServiceById($id, $array);
		}
		$array['cost'] = $cost;
		$this->load->model('service_model');
		$result = $this->service_model->getBigCategories($big_category_array);
		$result = $this->service_model->getSubCategories($array['big_category_id'], $sub_category_array);
		$this->load->model('user_model');
		$result = $this->user_model->get_members('provider', $provider_array);
		$data = array('data' => $array, 'error' => $error, 'featured' => $featured, 'page_type' => $page_type, 'big_category_array' => $big_category_array, 'sub_category_array' => $sub_category_array, 'provider_array' => $provider_array);
		$this->load->view('service_detail', $data);
	}
	function getSubCategoriesById()
	{
		$this->load->model('service_model');
		$result = $this->service_model->getSubCategories($_REQUEST['id'], $sub_category_array);
		
		if ($result == 200) {
			$error = "";
		} else {
			$error = "Invalid Service";
		}
		$data = array('data' => $sub_category_array, 'error' => $error);
		echo json_encode($data);
	}
	function translate($lang)
	{
		$_SESSION['lang'] = $lang;
		$this->go_category();
	}

	function go_category($big_category_id = '', $error = '')
	{
		$this->load->model('message_model');
		$result = $this->message_model->getUnreadMessages($_SESSION['id'], $array);
		$data = array('msg_badge' => $array['count'], 'active' => 'category');
		$this->load->view('header', $data);
		$this->load->model('service_model');
		$result = $this->service_model->getBigCategories($big_category_array);
		if (count($big_category_array) == 0) {
			$big_category_array = array();
		} else {
			if ($big_category_id == '') {
				$big_category_id = $big_category_array[0]['id'];
			}
			$result = $this->service_model->getSubCategories($big_category_id, $sub_category_array);
			$result = $this->service_model->getBigCategoryName($big_category_id, $big_category_name, $_SESSION['lang']);
			if ($result != 200) {
				$big_category_name = 'Please select a big category!';
			}
		}
		$data = array('error' => $error, 'big_category_array' => $big_category_array, 'sub_category_array' => $sub_category_array, 'big_category_id' => $big_category_id, 'big_category_name' => $big_category_name);
		$this->load->view('category', $data);
	}
	function update_category()
	{
		$type = $_REQUEST['type'];
		$name = trim($_REQUEST['name']);
		$id = $_REQUEST['id'];
		$big_category_id = $_REQUEST['big_category_id'];
		if ($name == "") {
			$error = "Please input name";
		} else {
			$this->load->model('service_model');
			$result = $this->service_model->update_category($type, $id, $big_category_id, $name, $error, $_SESSION['lang']);
		}
		$this->go_category($big_category_id, $error);
	}
	function delete_category($table, $id, $big_category_id)
	{
		$this->load->model('user_model');
		$result = $this->user_model->delete_item($table, $id);
		if ($result != 200) {
			$error = "Invalid category";
		} else {
			$error = "Successfully deleted";
		}
		$this->go_category($big_category_id, $error);
	}
	function change_status($id, $status, $featured, $day)
	{
		$this->load->model('user_model');
		$result = $this->user_model->change_status('tbl_service', $id, $status);
		if ($result != 200) {
			$error = 'Invalid Service';
		} else {
			$error = "Successfully changed.";
			if ($status == 'active') {
				$this->load->model('service_model');
				$result = $this->service_model->get_serviceById($id, $array);
				$this->load->model('service_model');
				$result = $this->service_model->getInterstArray($array['big_category_id'], $array['creator_id'], $token_array, $array['creator_type']);
				
				for ($i=0; $i < count($token_array); $i++) { 
					$this->push_android('service', $token_array[$i], $array['name'], $array['detail'], 0, $array);
				}
			}
		}
		$this->go_services($featured, $day, $error);
	}
	function delete_service($id, $featured, $day)
	{
		$this->load->model('user_model');
		$result = $this->user_model->delete_item('tbl_service', $id);
		if ($result != 200) {
			$error = 'Invalid Service';
		} else {
			$error = "Successfully deleted.";
		}
		$this->go_services($featured, $day, $error);
	}

	function image_upload()
    {	    	//FCPATH
		$config['upload_path']          =  FCPATH.'uploadImages/service/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 5000;
        $config['max_width']            = 4000;
        $config['max_height']           = 3000;
		$config['file_name'] 			= time();
		$config['overwrite']			= TRUE;
		
        $this->load->library('upload', $config);
        if ( ! $this->upload->do_upload('file'))
        {
            $error = array('error' => $this->upload->display_errors());
			// var_dump($config['upload_path']);
			echo 400;
        }
        else
        {
			$img_info = $this->upload->data();
            $image_info = array('full_path' => $img_info['full_path']);
            $url = base_url()."uploadImages/service/";
            $info = pathinfo($img_info['full_path']);
            $filename = $info['filename'];
            $extension = $info['extension'];
            $real_url = $url.$filename.'.'.$extension;
            $image_info = array('full_path' => $real_url);
			echo $filename.'.'.$extension;
        }    
	}
	function update_service()
	{
		$provider_id = 0;
		$service_type = $_REQUEST['service_type'];
		if (isset($_REQUEST['provider_id'])) {
			$provider_id = $_REQUEST['provider_id'];
		}
		
		$page_type = $_REQUEST['page_type'];
		$featured = $_REQUEST['featured'];
		$id = $_REQUEST['id'];
		$name = trim($_REQUEST['name']);

		if (isset($_REQUEST['sub_category_id'])) {
			$sub_category_id = $_REQUEST['sub_category_id'];
		} else {
			$sub_category_id = '';
		}
		
		$big_category_id = $_REQUEST['big_category_id'];
		$code = trim($_REQUEST['code']);
		$url = trim($_REQUEST['url']);
		$cost_d = trim($_REQUEST['cost_d']);
		$photo = trim($_REQUEST['photo']);
		$cost_w = trim($_REQUEST['cost_w']);
		$cost_m = trim($_REQUEST['cost_m']);
		$detail = trim($_REQUEST['detail']);
		$creator_id = $_SESSION['id'];
		$timestamp = time();
		$start_time = "";
		$end_time = "";
		$cost = "";
		if (isset($_REQUEST['start_time'])) {
			$start_time = $_REQUEST['start_time'];
		}
		if (isset($_REQUEST['end_time'])) {
			$end_time = $_REQUEST['end_time'];
		}
		if (isset($_REQUEST['cost'])) {
			$cost = $_REQUEST['cost'];
		}
		if ($name == '' || $big_category_id == '' || $sub_category_id == '' || $code == '' || $detail == '' || $cost_m == '' || $cost_w == '' || $cost_d == '' || $photo == '') {
			$error = 'Please fill in empty fields.';			
		} else if (filter_var($url, FILTER_VALIDATE_URL) == FALSE && strlen($url) > 0) {
		    $error = 'Invalid url format.';			
		} else if ($service_type == 'private' && $provider_id == '') {
		    $error = 'Please select provider.';
		} else if ($start_time > $end_time) {
		    $error = 'End time can not be lower than start time.';
		} else {
			$this->load->model('service_model');
			$result = $this->service_model->update_service($page_type, $id, $name, $big_category_id, $sub_category_id, $code, $url, $cost_d, $cost_w, $cost_m, $detail, $creator_id, $photo ,$featured, $timestamp, $service_type, $provider_id, $error, $likes, $dislikes, $totalViews, $start_time, $end_time, $status, $cost);
			if ($status == 'active') {
		// push notification to mobile users-------------------
				$this->load->model('service_model');
				$result = $this->service_model->getInterstArray($big_category_id, $creator_id, $token_array, $_SESSION['type']);
				// $type = "service"; 
				// if ($page_type == 'edit') {
				// 	$message = "New service has been posted from ".$_SESSION['username'];
				// }
				// $message = "New service has been posted from ".$_SESSION['username'];
				$service = array('id' => $id, 'name' => $name, 'featured' => $featured, 'sub_category_id' => $sub_category_id, 'big_category_id' => $big_category_id, 'code' => $code, 'url' => $url, 
					'cost_d' => $cost_d, 'cost_m' => $cost_m, 'cost_w' => $cost_w, 'detail' => $detail, 'image' => $photo, 'creator' => $_SESSION['username'], 'likes' => $likes, 'dislikes' => $dislikes, 'totalViews' => $totalViews, 'start_time' => $start_time, 'end_time' => $end_time);
				for ($i=0; $i < count($token_array); $i++) { 
					$this->push_android('service', $token_array[$i], $name, $detail, 0, $service);
				}
			}
		}

		$this->edit_service($page_type, $id, $featured, $error);
	}

	function push_android($type, $token, $title, $detail, $badge, $data = '')
	{
		$this->load->library('ci_pusher');
		$pusher = $this->ci_pusher->get_pusher();
		$result = $pusher->notify(
		  array($token),
		  array(
		    'gcm' => array(
		      'notification' => array(
		        'title' => $title,
		        'body' => $detail,
		        'icon' => 'androidlogo',
		        'sound' => 'default',
		      ),
		      'data' => array(
		      	'data' => $data,
		      		// 'badge' => intval($badge),
			      	// 'title' => $message),
		      	'type' => $type,
		      ),
		    ),
		    'webhook_url' => 'http://requestb.in/y0xssw70',
		    'webhook_level' => 'INFO',
		  )
		);
	}

	
}
?>