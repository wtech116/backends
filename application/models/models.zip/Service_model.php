<?php

class Service_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function get_invoices($id, &$array)
    {
    	$this->db->order_by("id", "desc");
    	if ($id == 1) {
			$array = $this->db->get_where('tbl_service', array('featured' => 1, 'deleted' => 0))->result_array();
    	} else {
    		$array = $this->db->get_where('tbl_service', array('creator_id' => $id, 'featured' => 1, 'deleted' => 0))->result_array();
    	}
		for ($i=0; $i < count($array); $i++) {
			$end = strtotime($array[$i]['end_time']); 
			$start = strtotime($array[$i]['start_time']); 
			$array[$i]['total_date'] = floor(($end - $start) / (3600*24));
			$array[$i]['total_cost'] = $array[$i]['total_date'] * $array[$i]['cost'];
			if ($array[$i]['created'] == 0) {
				$array[$i]['created'] = "";
			} else {
				$array[$i]['created'] = date("Y/m/d \<\b\\r\> h/i/s A", $array[$i]['created']);
			}
			if ($array[$i]['updated'] == 0) {
				$array[$i]['updated'] = "";
			} else {
				$array[$i]['updated'] = date("Y/m/d \<\b\\r\> h/i/s A", $array[$i]['updated']);
			}
		}
		return 200;
    }
	
	function getInterstArray($big_category_id, $creator_id, &$token_array, $type)
	{
		$token_array = array();
		$id_array = array();

		if ($creator_id == 1) {
			$result = $this->db->get_where('tbl_user', array('type' => 'user', 'deleted' => 0))->result_array();
			for ($i=0; $i < count($result); $i++) { 
				array_push($token_array, $result[$i]['token']);
			}
			return 200;
		}

		$result1 = $this->db->get_where('tbl_interest', array('type' => 'category', 'in_id' => $big_category_id))->result_array();
		$result2 = $this->db->get_where('tbl_interest', array('type' => $type, 'in_id' => $creator_id))->result_array();
		for ($i=0; $i < count($result1); $i++) { 
			for ($j=0; $j < count($result2); $j++) { 
				if ($result1[$i]['user_id'] == $result2[$j]['user_id']) {
					array_push($id_array, $result1[$i]['user_id']);
				}
			}
		}
		for ($i=0; $i < count($id_array); $i++) { 
			$result = $this->db->get_where('tbl_user', array('id' => $id_array[$i], 'deleted' => 0))->result_array();
			if (count($result) > 0) {
				array_push($token_array, $result[0]['token']);
			}
		}
		return 200;
	}
	

	function get_serviceById($id, &$array)
	{
		$result = $this->db->get_where('tbl_service', array('id' => $id))->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$array = $result[0];
		// $array['image'] = base_url().'uploadImages/service/'.$array['image'];
		$result = $this->db->get_where('tbl_user', array('id' => $array['creator_id']))->result_array();
		$array['creator'] = $result[0]['username'];
		$array['creator_type'] = $result[0]['type'];
		$result = $this->db->get_where('tbl_big_category', array('id' => $array['big_category_id']))->result_array();
		$array['big_category'] = $result[0]['name'];
		$result = $this->db->get_where('tbl_sub_category', array('id' => $array['sub_category_id']))->result_array();
		$array['sub_category'] = $result[0]['name'];
		return 200;
	}
	function getBigCategories(&$array)
	{
		$array = $this->db->get_where('tbl_big_category', array('deleted' => 0))->result_array();
		return 200;
	}
	function getSubCategories($big_category_id, &$array)
	{
		if ($big_category_id == 0) {
			$array = $this->db->get_where('tbl_sub_category', array('deleted' => 0))->result_array();
		} else {
			$array = $this->db->get_where('tbl_sub_category', array('big_category_id' => $big_category_id, 'deleted' => 0))->result_array();
		}
		return 200;
	}
	function getBigCategoryName($big_category_id, &$big_category_name, $lang = 'eng')
	{
		$result = $this->db->get_where('tbl_big_category', array('id' => $big_category_id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$big_category_name = $result[0]['name'];
		if ($lang != 'eng') {
			$big_category_name = $result[0]['french'];
		}
		return 200;
	}
	function get_AllSubjects($my_type, $my_id, &$array)
	{
		$array = array();
		$result = $this->db->get_where('tbl_service', array('deleted' => 0))->result_array();
		
		for ($i=0; $i < count($result); $i++) { 
			if ($my_type == 'operator' && $my_id != $result[$i]['creator_id']) {
				continue;
			}
			$item['id'] = $result[$i]['id'];
			$item['name'] = $result[$i]['name'];
			$result1 = $this->db->get('tbl_user', array('id' => $result[$i]['creator_id']))->result_array();
			$item['creator'] = $result1[0]['username'];
			array_push($array, $item);
		}
		return 200;
	}
	function update_category($type, $id, $big_category_id, $name, &$error, $lang = 'eng')
	{
		$field = 'name';
		if ($lang != 'eng') {
			$field = 'french';
		}
		if ($big_category_id == 0) {
			$table = 'tbl_big_category';
			$insert_arr = array($field => $name);
		} else {
			$table = 'tbl_sub_category';
			$insert_arr = array($field => $name, 'big_category_id' => $big_category_id);
		}
		if ($type == 'edit') {
			$this->db->where('id', $id);
			$this->db->update($table, array($field => $name));
			$error = 'Successfully updated';
		} else {
			$this->db->insert($table, $insert_arr);
			$error = 'Successfully added';
		}
		
		return 200;
	}
	function update_service($page_type, &$id, $name, $big_category_id, $sub_category_id, $code, $url, $cost_d, $cost_w, $cost_m, $detail, $creator_id, $photo ,$featured, $timestamp, $service_type, $provider_id, &$error, &$likes, &$dislikes, &$totalViews, $start_time, $end_time, &$status, $cost)
	{
		if ($page_type == 'edit') {
			$this->db->where('id', $id);
			$this->db->update('tbl_service', array('image' => $photo, 'name' => $name, 'big_category_id' => $big_category_id, 'sub_category_id' => $sub_category_id, 'code' => $code, 'url' => $url, 
				'cost_d' => $cost_d, 'cost_w' => $cost_w, 'cost_m' => $cost_m, 'detail' => $detail, 'creator_id' => $creator_id, 'featured' => $featured, 'updated' => $timestamp, 'type' => $service_type, 'provider_id' => $provider_id, 'start_time' => $start_time, 'end_time' => $end_time, 'cost' => $cost));
			$error = 'Successfully updated';
		} else {
			if ($featured == 1) {
				$status = 'inactive';
			} else {
				$status = 'active';
			}
			$this->db->insert('tbl_service', array('image' => $photo, 'name' => $name, 'big_category_id' => $big_category_id, 'sub_category_id' => $sub_category_id, 'code' => $code, 'url' => $url, 
				'cost_d' => $cost_d, 'cost_w' => $cost_w, 'cost_m' => $cost_m, 'detail' => $detail, 'creator_id' => $creator_id, 'featured' => $featured, 'created' => $timestamp, 'status' =>$status, 'type' => $service_type, 'provider_id' => $provider_id, 'start_time' => $start_time, 'end_time' => $end_time, 'cost' => $cost));
			$id = $this->db->insert_id();
			$error = 'Successfully added';
		}
		$result = $this->db->get_where('tbl_service', array('id' => $id))->result_array();
		$likes = $result[0]['likes'];
		$dislikes = $result[0]['dislikes'];
		$totalViews = $result[0]['total_views'];
		$status = $result[0]['status'];
		return 200;
	}
	function checkFeaturedServices()
	{
		$today = date("Y-m-d");
		$this->db->where('end_time<', $today);
		$this->db->where('featured', 1);
		$this->db->where('deleted', 0);
		$this->db->update('tbl_service', array('deleted' => 1));
	}

}

?>