<?php

class Mobile_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function login($email, $password, $token, &$out_array)
    {
		$query = $this->db->get_where('tbl_user', array('email' => $email, 'password' => $password, 'deleted' => 0));
		$result = $query->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User Information';
			return 400;
		}
		$out_array = $result[0];
		$status = $result[0]['status'];
		
		switch ($status) {
			case 'inactive':
				$out_array['reason'] = 'User is inactive';
				$code = 400;
				break;
			case 'active':
				$out_array['reason'] = 'User is active';
				$code = 200;
				break;
			default:
				$out_array['reason'] = 'Invalid User';
				$code = 400;
				break;
		}
		$this->db->where('id', $result[0]['id']);
		$this->db->update('tbl_user', array('token' => $token));
		return $code;
    }
    function signup($email, $password, $username, $code, $number, $token,  &$out_array, $id='', $type='new')
    {
		$this->db->where('username', $username);
		$this->db->where('deleted', 0);
		$result = $this->db->get('tbl_user')->result_array();
		if (count($result) > 0) {
			if ($type == 'new') {
				$out_array['reason'] = 'Username already exists';
				return 400;
			}
			if ($result[0]['id'] != $id) {
				$out_array['reason'] = 'Username already exists';
				return 400;
			}
		}
		$this->db->where('email', $email);
		$this->db->where('deleted', 0);
		$result = $this->db->get('tbl_user')->result_array();
		if (count($result) > 0) {
			if ($type == 'new') {
				$out_array['reason'] = 'Email already exists';
				return 400;
			}
			if ($result[0]['id'] != $id) {
				$out_array['reason'] = 'Email already exists';
				return 400;
			}
		}
		if ($type == 'edit') {
			$this->db->where('id', $id);
			$this->db->update('tbl_user', array('username' => $username, 'email' => $email, 'password' => $password, 'country_code' => $code, 'number' => $number, 'created' => time(), 'token' => $token));
			$out_array['reason'] = 'Successfully updated';
		} else {
			$this->db->insert('tbl_user', array('username' => $username, 'email' => $email, 'password' => $password, 'country_code' => $code, 'number' => $number, 'status' => 'active', 'created' => time(), 'type' => 'user', 'token' => $token));
			$out_array['id'] = $this->db->insert_id();
			$out_array['reason'] = 'Successfully added';

		}
		$out_array['email'] = $email; $out_array['password'] = $password; $out_array['username'] = $username; $out_array['number'] = $number; $out_array['code'] = $code;
		return 200;
    }
    function fb_login($email, $name, $code, $token, &$out_array)
    {
		$query = $this->db->get_where('tbl_user', array('email' => $email, 'username' => $name));
		$result = $query->result_array();
		if (count($result) == 0) {
			$this->db->insert('tbl_user', array('username' => $name, 'type' => 'user', 'email' => $email, 'country_code' => $code, 'status' => 'active', 'created' => time()));
			$out_array['id'] = $this->db->insert_id();
			$out_array['reason'] = 'Successfully added';
			$out_array['email'] = $email; $out_array['password'] = ''; $out_array['username'] = $name; $out_array['code'] = $code; $out_array['number'] = '';
		} else {
			$out_array = $result[0];
		}
		$this->db->where('id', $out_array['id']);
		$this->db->update('tbl_user', array('token' => $token));

		return 200;
    }
	function search_services($id, $search_key, &$array)
	{
		$this->db->where('creator_id', $id);
		$this->db->where('status', 'active');
		$this->db->like('name', $search_key, 'both'); 
		$this->db->order_by("id", "desc");
		$array = $this->db->get('tbl_service')->result_array();
		for ($i=0; $i < count($array); $i++) { 
			$creator_id = $array[$i]['creator_id'];		
			$result = $this->db->get_where('tbl_user', array('id' => $creator_id))->result_array();			
			$array[$i]['creator'] = $result[0]['username'];
			$array[$i]['image'] = base_url().'uploadImages/service/'.$array[$i]['image'];
		}
		return 200;
	}
	function get_services($id, $featured)
   {
    	$array = array();
		$this->db->where('creator_id', $id);
    	$this->db->where('featured', $featured);
    	$this->db->where('status', 'active');
    	$this->db->where('deleted', 0);
		$this->db->order_by("id", "desc");
		$result1 = $this->db->get('tbl_service')->result_array();
		$array = $result1;
		for ($i=0; $i < count($result1); $i++) { 
			$array[$i]['image'] = base_url().'uploadImages/service/'.$array[$i]['image'];
			$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['creator_id']))->result_array();
			$array[$i]['creator'] = $result[0]['username'];
			$result = $this->db->get_where('tbl_big_category', array('id' => $array[$i]['big_category_id']))->result_array();
			$array[$i]['big_category'] = $result[0]['name'];
			$result = $this->db->get_where('tbl_sub_category', array('id' => $array[$i]['sub_category_id']))->result_array();
			$array[$i]['sub_category'] = $result[0]['name'];
		}

		$this->db->where('creator_id', 1);
    	$this->db->where('featured', $featured);
    	$this->db->where('status', 'active');
    	$this->db->where('deleted', 0);
		$this->db->order_by("id", "desc");
		$result2 = $this->db->get('tbl_service')->result_array();
		for ($i=0; $i < count($result2); $i++) { 
			$result2[$i]['image'] = base_url().'uploadImages/service/'.$result2[$i]['image'];
			$result = $this->db->get_where('tbl_user', array('id' => $result2[$i]['creator_id']))->result_array();
			$result2[$i]['creator'] = $result[0]['username'];
			$result = $this->db->get_where('tbl_big_category', array('id' => $result2[$i]['big_category_id']))->result_array();
			$result2[$i]['big_category'] = $result[0]['name'];
			$result = $this->db->get_where('tbl_sub_category', array('id' => $result2[$i]['sub_category_id']))->result_array();
			$result2[$i]['sub_category'] = $result[0]['name'];
			array_push($array, $result2[$i]);
		}
		return $array;
   }
   function add_like($id, $islike, &$array)
   {
   		$result = $this->db->get_where('tbl_service', array('id' => $id, 'deleted' => 0))->result_array();
   		if (count($result) == 0) {
   			$array['reason'] == 'Invalid Service!';
   			return 400;
   		}
   		$likes = $result[0]['likes'];
   		$dislikes = $result[0]['dislikes'];
   		if ($islike == 1) {
	   		$likes = $likes + 1;
   		} else {
   			$dislikes = $dislikes + 1;
   		}
   		$this->db->where('id', $id);
   		$this->db->update('tbl_service', array('likes' => $likes, 'dislikes' => $dislikes));
   		$array['likes'] = $likes;
   		$array['dislikes'] = $dislikes;
   		return 200;
   }
   function get_all_services(&$array)
   {
   		$array = $this->db->get_where('tbl_service', array('status' => 'active', 'deleted' => 0))->result_array();
   		for ($i=0; $i < count($array); $i++) { 
			$array[$i]['image'] = base_url().'uploadImages/service/'.$array[$i]['image'];
			$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['creator_id']))->result_array();
			$array[$i]['creator'] = $result[0]['username'];
			$result = $this->db->get_where('tbl_big_category', array('id' => $array[$i]['big_category_id']))->result_array();
			$array[$i]['big_category'] = $result[0]['name'];
			$result = $this->db->get_where('tbl_sub_category', array('id' => $array[$i]['sub_category_id']))->result_array();
			$array[$i]['sub_category'] = $result[0]['name'];
		}
		return 200;
   }
	function get_all_members(&$array)
	{
		$array = $this->db->get_where('tbl_user', array('status' => 'active', 'deleted' => 0))->result_array();
		return 200;
	}
	function compare($service_name, $operator_array, &$array)
	{
		$array = $this->db->get_where('tbl_service', array('name' => $service_name, 'status' => 'active', 'deleted' => 0))->result_array();
		for ($i=0; $i < count($array); $i++) { 
			if (count($operator_array) > 0) {
				if (!in_array($array[$i]['creator_id'], $operator_array)) {
					continue;
				}
			}
			$array[$i]['image'] = base_url().'uploadImages/service/'.$array[$i]['image'];
			$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['creator_id']))->result_array();
			$array[$i]['creator'] = $result[0]['username'];
			$result = $this->db->get_where('tbl_big_category', array('id' => $array[$i]['big_category_id']))->result_array();
			$array[$i]['big_category'] = $result[0]['name'];
			$result = $this->db->get_where('tbl_sub_category', array('id' => $array[$i]['sub_category_id']))->result_array();
			$array[$i]['sub_category'] = $result[0]['name'];
		}
		return 200;
	}
	function add_message($sender_id, $receiver_arr, $service_id, $content ,$concern_id, $created)
	{
		if (count($receiver_arr) == 0) {
			$type = 'public';
			$this->db->insert('tbl_message', array('sender_id' => $sender_id, 'service_id' => $service_id, 'content' => $content
				, 'concern_id' => $concern_id, 'type' => $type, 'created' => $created));
		} else {
			$type = 'private';
			for ($i=0; $i < count($receiver_arr); $i++) { 
				$this->db->insert('tbl_message', array('sender_id' => $sender_id, 'receiver_id' => $receiver_arr[$i], 'service_id' => $service_id
					, 'content' => $content, 'concern_id' => $concern_id, 'type' => $type, 'created' => $created));
			}
		}
		return 200;
	}
	function update_profile($in_array, &$out_array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $in_array['id'], 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User';
			return 400;
		}
		$id = $in_array['id'];
		unset($in_array['id']);
		$this->db->where('id', $id);
		$this->db->update('tbl_user', $in_array);
		$out_array = $in_array;
		return 200;
	}
	function load_interest($id, &$out_array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User';
			return 400;
		}
		$operator_arr = $this->db->get_where('tbl_interest', array('user_id' => $id, 'type' => 'operator'))->result_array();
		for ($i=0; $i < count($operator_arr); $i++) { 
			$out_array['operator'][$i] = $this->db->get_where('tbl_user', array('id' => $operator_arr[$i]['in_id']))->result_array()[0];
		}
		$provider_arr = $this->db->get_where('tbl_interest', array('user_id' => $id, 'type' => 'provider'))->result_array();
		for ($i=0; $i < count($provider_arr); $i++) { 
			$out_array['provider'][$i] = $this->db->get_where('tbl_user', array('id' => $provider_arr[$i]['in_id']))->result_array()[0];
		}
		$category_arr = $this->db->get_where('tbl_interest', array('user_id' => $id, 'type' => 'category'))->result_array();
		for ($i=0; $i < count($category_arr); $i++) { 
			$out_array['category'][$i] = $this->db->get_where('tbl_big_category', array('id' => $category_arr[$i]['in_id']))->result_array()[0];
		}
		return 200;
	}
	function add_interest_operator($id, $operator_arr, &$out_array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User';
			return 400;
		}
		$this->db->delete('tbl_interest', array('user_id' => $id, 'type' => 'operator'));
		for ($i=0; $i < count($operator_arr); $i++) { 
			$this->db->insert('tbl_interest', array('user_id' => $id, 'type' => 'operator', 'in_id' => $operator_arr[$i]));
		}
		return 200;
	}
	function add_interest_provider($id, $provider_arr, &$out_array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User';
			return 400;
		}
		$this->db->delete('tbl_interest', array('user_id' => $id, 'type' => 'provider'));
		for ($i=0; $i < count($provider_arr); $i++) { 
			$this->db->insert('tbl_interest', array('user_id' => $id, 'type' => 'provider', 'in_id' => $provider_arr[$i]));
		}
		return 200;
	}
	function add_interest_category($id, $category_arr, &$out_array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			$out_array['reason'] = 'Invalid User';
			return 400;
		}
		$this->db->delete('tbl_interest', array('user_id' => $id, 'type' => 'category'));
		for ($i=0; $i < count($category_arr); $i++) { 
			$this->db->insert('tbl_interest', array('user_id' => $id, 'type' => 'category', 'in_id' => $category_arr[$i]));
		}
		return 200;
	}
	function view_service($id, &$array)
	{
   		$result = $this->db->get_where('tbl_service', array('id' => $id, 'deleted' => 0))->result_array();
   		if (count($result) == 0) {
   			$array['reason'] == 'Invalid Service!';
   			return 400;
   		}
   		$total_views = $result[0]['total_views'];
   		$this->db->where('id', $id);
   		$this->db->update('tbl_service', array('total_views' => $total_views+1));
   		return 200;
	}












    function getCodeFromIso($code)
    {
		$query = $this->db->get_where('tbl_country', array('iso' => strtoupper($code)));
		$result = $query->result_array();
		return $result[0]['phonecode'];
    }

  	function get_operators(&$array)
	{
		$this->db->where('status', 'active');
		$array['data'] = $this->db->get('tbl_operator')->result_array();
		return 200;
	}

	function get_operator_projects($operator_id, $isFeatured, &$out_array)
	{
		$this->db->where('creator_id', $operator_id);
		$this->db->where('status', 'active');
		$this->db->where('featured', $isFeatured);
		$out_array['data'] = $this->db->get('tbl_project')->result_array();
		for ($i=0; $i < count($out_array['data']); $i++) { 
			$creator_id = $out_array['data'][$i]['creator_id'];
			if ($creator_id == 0) {
				$out_array['data'][$i]['creator'] = "ADMIN";
			} else {
				$result = $this->db->get_where('tbl_operator', array('id' => $creator_id))->result_array();
				
				$out_array['data'][$i]['creator'] = $result[0]['realname'];
			}
		}
		return 200;
	}

	
	function get_featured_projects($creator_id, &$out_array)
	{
		$this->db->where('status', 'active');
		$this->db->where('creator_id', $creator_id);
		$this->db->where('featured', '1');
		$out_array['data'] = $this->db->get('tbl_project')->result_array();
		for ($i=0; $i < count($out_array['data']); $i++) { 
			$creator_id = $out_array['data'][$i]['creator_id'];
			if ($creator_id == 0) {
				$out_array['data'][$i]['creator'] = "ADMIN";
			} else {
				$result = $this->db->get_where('tbl_operator', array('id' => $creator_id))->result_array();
				
				$out_array['data'][$i]['creator'] = $result[0]['realname'];
			}
		}
		return 200;
	}
	function get_all_projects($code, &$out_array)
	{
		$result = $this->db->get_where('tbl_operator', array('code' => $code))->result_array();
		if (count($result) == 0) {
			$out_array = array();
			return 200;
		}
		$operator_id = $result[0]['id'];

		$this->db->where("`creator_id`=".$operator_id." AND `status`='active'");
		$this->db->or_where("`creator_id`='0' AND `status`='active'");		
		$out_array['data'] = $this->db->get('tbl_project')->result_array();
		for ($i=0; $i < count($out_array['data']); $i++) { 
			$creator_id = $out_array['data'][$i]['creator_id'];
			if ($creator_id == 0) {
				$out_array['data'][$i]['creator'] = "ADMIN";
			} else {
				$result = $this->db->get_where('tbl_operator', array('id' => $creator_id))->result_array();
				$out_array['data'][$i]['creator'] = $result[0]['realname'];
			}
		}
		return 200;
	}
}

?>