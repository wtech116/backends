<?php

class Message_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function getUnreadMessages($receiver_id, &$array)
    {
    	$result = $this->db->get_where('tbl_user', array('id' => $receiver_id, 'deleted' => 0))->result_array();
    	if (count($result) == 0) {
    		$array['reason'] = 'Invalid user!';
    		return 400;
    	}
    	$result1 = $this->db->get_where('tbl_message', array('receiver_id' => $receiver_id, 'type' => 'private', 'isread' => 0, 'deleted' => 0))->result_array();
    	$this->db->where('sender_id!=', $receiver_id);
    	$this->db->where(array('type' => 'public', 'isread' => 0, 'deleted' => 0));
    	$result2 = $this->db->get('tbl_message')->result_array();
    	$array['count'] = count($result1) + count($result2);
    	return 200;
    }
	function getInbox($receiver_id, &$array)
	{
		$my_code = $this->db->get_where('tbl_user', array('id' => $receiver_id))->row()->country_code;
		
		$array = array();
		$this->db->where(array('receiver_id' => $receiver_id, 'deleted' => 0));
		// $this->db->or_where(array('type' => 'public', 'deleted' => 0));
		$this->db->or_where("`type`='public' AND `deleted`='0'");
		$this->db->order_by("id","desc");
		// $this->db->or_where(array('sender_id!=' => $receiver_id, 'sender_type!=' => $receiver_type, 'type' =>'public', 'deleted' => 0));
		$res = $this->db->get('tbl_message')->result_array();
		$i = -1;
		for ($j=0; $j < count($res); $j++) { 
			if ($res[$j]['sender_id'] == $receiver_id) {
				continue;
			}
			$i ++;
			$array[$i] = $res[$j];
			$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['sender_id']))->result_array();
			$array[$i]['sender_type'] = $result[0]['type'];
			if ($array[$i]['sender_type'] != 'admin' && $my_code != $result[0]['country_code'] && $receiver_id != 1) {
				unset($array[$i]);
				$i --; continue;
			}
			$array[$i]['sender'] = $result[0]['username'];
			
			$result = $this->db->get_where('tbl_service', array('id' => $array[$i]['service_id']))->result_array();
			if (count($result) > 0) {
				$array[$i]['service_name'] = $result[0]['name'];
			} else if ($array[$i]['service_id'] == 0) {
				$array[$i]['service_name'] = "Admin Announcements";
			} else {
				$array[$i]['service_name'] = "";
			}
			$result = $this->db->get_where('tbl_concern', array('id' => $array[$i]['concern_id']))->result_array();
			if (count($result) > 0) {
				$array[$i]['concern_name'] = $result[0]['name'];
			} else if ($array[$i]['concern_id'] == 0) {
				$array[$i]['concern_name'] = "Admin Announcements";
			} else {
				$array[$i]['concern_name'] = "";
			}
			$array[$i]['time'] = date('d/m/Y h:i a', $array[$i]['created']);
			$array[$i]['receiver_type'] = '';
			$array[$i]['receiver'] = '';
		}
		return 200;
	}
	function fetch_messageById($id, $flag, &$array)
	{
		$query = $this->db->get_where('tbl_message', array('id' => $id));
		$result = $query->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$array = $result[0];
		$result = $this->db->get_where('tbl_user', array('id' => $array['sender_id']))->result_array();
		$array['sender'] = $result[0]['username'];	
		$array['sender_type'] = $result[0]['type'];
		
		if ($array['type'] == "public") {
			$array['receiver'] = "ALL";
			$array['receiver_id'] = 0;
		} else {
			$result = $this->db->get_where('tbl_user', array('id' => $array['receiver_id']))->result_array();
			$array['receiver'] = $result[0]['username'];
			$array['receiver_type'] = $result[0]['type'];
		}
		$result = $this->db->get_where('tbl_service', array('id' => $array['service_id']))->result_array();
		if (count($result) > 0) {
			$array['service_name'] = $result[0]['name'];
		} else if ($array['service_id'] == 0) {
			$array['service_name'] = "Admin Announcements";
		} else {
			$array['service_name'] = "";
		}
		$result = $this->db->get_where('tbl_concern', array('id' => $array['concern_id']))->result_array();
		if (count($result) > 0) {
			$array['concern_name'] = $result[0]['name'];
		} else if ($array['concern_id'] == 0) {
			$array['concern_name'] = "Admin Announcements";
		} else {
			$array['concern_name'] = "";
		}
		$array['time'] = date('d/m/Y h:i a', $array['created']);
		if ($flag == TRUE) {
			$this->db->where('id', $id);
			$this->db->update('tbl_message', array('isread' => 1));
		}
		return 200;
	}
	function getSent($sender_id, &$array)
	{
		$array = array();
		$this->db->where(array('sender_id' => $sender_id, 'deleted' => 0));
		$this->db->order_by("id","desc");
		$array = $this->db->get('tbl_message')->result_array();
		$cnt = count($array);
		for ($i=0; $i < $cnt; $i++) {
			if ($array[$i]['type'] == "public") {
				$array[$i]['receiver'] = "ALL";
				$array[$i]['receiver_type'] = "";
			} else {
				$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['receiver_id']))->result_array();
				$array[$i]['receiver'] = $result[0]['username'];
				$array[$i]['receiver_type'] = $result[0]['type'];
			}
			$query = $this->db->get_where('tbl_service', array('id' => $array[$i]['service_id']));
			$result = $query->result_array();
			if (count($result) > 0) {
				$array[$i]['service_name'] = $result[0]['name'];
			} else if ($array[$i]['service_id'] == 0) {
				$array[$i]['service_name'] = "Admin Announcements";
			} else {
				$array[$i]['service_name'] = "";
			}
			$query = $this->db->get_where('tbl_concern', array('id' => $array[$i]['concern_id']));
			$result = $query->result_array();
			if (count($result) > 0) {
				$array[$i]['concern_name'] = $result[0]['name'];
			} else if ($array[$i]['concern_id'] == 0) {
				$array[$i]['concern_name'] = "Admin Announcements";
			} else {
				$array[$i]['concern_name'] = "";
			}
			$array[$i]['time'] = date('d/m/Y h:i a', $array[$i]['created']);
			$array[$i]['sender_type'] = '';
			$array[$i]['sender'] = '';
		}
		return 200;
	}
	function get_AllConcerns(&$c_array)
	{
		$c_array = $this->db->get('tbl_concern')->result_array();
		return 200;
	}
	function add_message($sender_id, $receiver_arr, $service_id, $content ,$concern_id, $timestamp)
	{
		for ($i=0; $i < count($receiver_arr); $i++) { 

			if ($receiver_arr[$i] == 0) {
				$type = "public";
			} else {
				$type = "private";
			}
			
			$this->db->insert('tbl_message', array('sender_id' => $sender_id, 'receiver_id' => $receiver_arr[$i], 
				'service_id' => $service_id, 'content' => $content, 'concern_id' => $concern_id, 'type' => $type, 'created' => $timestamp));
		}
		return 200;
	}
	function getTokenArray($id_array, &$token_array) {
		$token_array = array();
		if (in_array("0", $id_array)) {
			$result = $this->db->get_where('tbl_user', array('type' => 'user', 'deleted' => 0))->result_array();
			for ($i=0; $i < count($result); $i++) { 
				array_push($token_array, $result[$i]['token']);
			}
			return 200;
		}

		for ($i=0; $i < count($id_array); $i++) { 
			$result = $this->db->get_where('tbl_user', array('id' => $id_array[$i], 'deleted' => 0))->result_array();
			if (count($result) > 0) {
				array_push($token_array, $result[0]['token']);
			}
		}
	}
	function getUsername($user_id) {
		$result = $this->db->get_where('tbl_user', array('id' => $user_id))->result_array();
		return $result[0]['username'];
	}
	function getServicename($service_id) {
		if ($service_id == 0) {
			return "Admin Announcements";
		}
		$result = $this->db->get_where('tbl_service', array('id' => $service_id))->result_array();
		return $result[0]['name'];
	}























}

?>