<?php
define("SECRET", 'ujs');
class Admin_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }
	
	function loginAdmin($username, $password, &$reason)
	{
		$query = $this->db->get_where('tbl_subadmin', array('username' => $username, 'password' => $password));
		$result = $query->result_array();
		if (count($result) == 0) {
			$reason = 'Invalid User Information';
			return 400;
		}
		$status = $result[0]['status'];
		
		switch ($status) {
			case 'inactive':
				$reason = 'User is inactive';
				$code = 400;
				break;
			case 'active':
				$reason = 'User is active';
				$code = 200;
				break;
			default:
				$reason = 'Invalid User';
				$code = 400;
				break;
		}
		
		return $code;
	}
	function get_admin_cost(&$cost)
	{
		$result = $this->db->get_where('tbl_admin', array('ikey' => 'cost'))->result_array();
		$cost = $result[0]['ivalue'];
		return 200;
	}
	function set_admin_cost($cost)
	{
		$this->db->where('ikey', 'cost');
		$this->db->update('tbl_admin', array('ivalue' => $cost));
		return 200;
	}

	function loginOperator($username, $password, &$reason)
	{
		$query = $this->db->get_where('tbl_operator', array('username' => $username, 'password' => $password));
		$result = $query->result_array();
		if (count($result) == 0) {
			$reason = 'Invalid User';
			return 400;
		}
		$status = $result[0]['status'];
		
		switch ($status) {
			case 'inactive':
				$reason = 'User is inactive';
				$code = 400;
				break;
			case 'active':
				$reason = 'User is active';
				$code = 200;
				break;
			default:
				$reason = 'Invalid User';
				$code = 400;
				break;
		}
		
		return $code;
	}
	
	function update_admin($username, $password, $photo)
	{
		$this->db->where('ikey', 'username');
		$this->db->update('tbl_admin', array('ivalue' => $username));
		$this->db->where('ikey', 'password');
		$this->db->update('tbl_admin', array('ivalue' => $password));
		$this->db->where('ikey', 'photo');
		$this->db->update('tbl_admin', array('ivalue' => $photo));
	}
	
	function get_admin($username, &$array)
	{
		$array = array();
		$query = $this->db->get_where('tbl_subadmin', array('username' => $username));
		$result = $query->result_array();
		if (count($result) > 0) {
			$array = $result[0];
			return 200;
		}
		return 400;
	}
	function get_operator($username, &$array)
	{
		$array = array();
		$query = $this->db->get_where('tbl_operator', array('username' => $username));
		$result = $query->result_array();
		if (count($result) > 0) {
			$array = $result[0];
			return 200;
		}
		return 400;
	}
	function get_date()
	{
		$query = $this->db->get_where('tbl_admin', array('ikey' => 'date'));
		$result = $query->result_array();
		return $result[0]['ivalue'];
		
	}
	function set_date($value)
	{
		$query = $this->db->get_where('tbl_admin', array('ikey' => 'date'));
		$result = $query->result_array();
		if (count($result) == 0) {
			$this->db->insert('tbl_admin', array('ikey' => 'date', 'ivalue' => $value));			
		}else {
			$this->db->where('ikey', 'date');
			$this->db->update('tbl_admin', array('ivalue' => $value));
		}
		return 200;
	}	
	
	function get_newUserCount()
	{
		$query = $this->db->get_where('tbl_user', array('block' => 2, 'deleted' => 0));
		$result = $query->result_array();
		return count($result);
	}
}