<?php

class User_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function login($email, $password, $type, &$out_array)
    {
    	$result = $this->db->get_where('tbl_user', array('email' => $email, 'type' => $type, 'deleted' => 0))->result_array();
    	if (count($result) == 0) {
    		$out_array['reason'] = 'Invalid user!';
    		return 400;
    	}
    	if ($result[0]['password'] != $password) {
    		$out_array['reason'] = 'Password is not correct!';
    		return 400;
    	}
    	if ($result[0]['status'] == 'inactive') {
    		$out_array['reason'] = 'Account is inactive!';
    		return 400;
    	}
    	$out_array = $result[0];
    	return 200;
    }
    function checkEmail($email, &$out_array)
    {
    	$result = $this->db->get_where('tbl_user', array('email' => $email, 'deleted' => 0))->result_array();
    	if (count($result) == 0) {
    		$out_array['reason'] = 'Invalid user!';
    		return 400;
    	}
    	$out_array = $result[0];
    	return 200;
    }
    function checkId($id, &$out_array)
    {
    	$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
    	if (count($result) == 0) {
    		$out_array['reason'] = 'Invalid user!';
    		return 400;
    	}
    	$out_array = $result[0];
    	return 200;
    }
    function update_password($id, $password, &$error)
    {
    	$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
    	if (count($result) == 0) {
    		$error = 'Invalid user!';
    		return 400;
    	}
    	$this->db->where('id', $id);
    	$this->db->update('tbl_user', array('password' => $password));
    	$error = 'success';
    	return 200;
   }

    function get_statistics(&$array)
    {
    	$array = array();
    	// user statistics
		$array['user'][0] = count($this->get_usersByDay("daily"));
		$array['user'][1] = count($this->get_usersByDay("weekly"));
		$array['user'][2] = count($this->get_usersByDay("monthly"));
		$array['user'][3] = count($this->get_usersByDay());
		// service statistics
		$array['service'][0] = count($this->get_servicesByDay("daily"));
		$array['service'][1] = count($this->get_servicesByDay("weekly"));
		$array['service'][2] = count($this->get_servicesByDay("monthly"));
		$array['service'][3] = count($this->get_servicesByDay());

		$this->get_service_statistics('provider', 0, $array['provider']);
		$this->get_service_statistics('provider', 1, $array['provider_featured']);
		$this->get_service_statistics('operator', 0, $array['operator']);
		$this->get_service_statistics('operator', 1, $array['operator_featured']);

		// $this->get_service_provider_statistics($id, 0, $array['s_provider']);
		// $this->get_service_provider_statistics($id, 1, $array['s_provider_featured']);
		return 200;
    }
    // function get_service_provider_statistics($featured, &$array)
    // {

    // }

    function get_service_statistics($type, $featured, &$array) {
    	$d_timestamp =strtotime("today");
    	$w_timestamp =strtotime("Last Monday");
    	$m_timestamp = strtotime(date('Y-m-01 00:00:00'));
    	$result = $this->db->get_where('tbl_user', array('type' => $type, 'deleted' => 0))->result_array();
		for ($i=0; $i <count($result) ; $i++) { 
			$array[$i]['user_id'] = $result[$i]['id'];
			$array[$i]['username'] = $result[$i]['username'];
			$array[$i]['provider_id_array'] = array();
			
			$rst = $this->db->get_where('tbl_service', array('creator_id' => $array[$i]['user_id'], 'type' => 'private'))->result_array();
			for ($j=0; $j < count($rst); $j++) { 
				array_push($array[$i]['provider_id_array'], $rst[$j]['provider_id']);
			}
			
			$array[$i]['service'][0] = count($this->get_servicesById_Featured_Day($result[$i]['id'], $featured, "daily"));
			$array[$i]['service'][1] = count($this->get_servicesById_Featured_Day($result[$i]['id'], $featured, "weekly"));
			$array[$i]['service'][2] = count($this->get_servicesById_Featured_Day($result[$i]['id'], $featured, "monthly"));
			$array[$i]['service'][3] = count($this->get_servicesById_Featured_Day($result[$i]['id'], $featured));
		}
    }
    // --------------------------------------------------------------------------------------------------------------
   function get_usersByDay($day = "all")
   {
    	$array = array();
    	if ($day == "daily") {
	    	$timestamp =strtotime("today");
    	} else if ($day == "weekly") {
    		$timestamp =strtotime("Last Monday");
    	} else if ($day == "monthly") {
    		$timestamp =strtotime(date('Y-m-01 00:00:00'));
    	} else {
    		$timestamp = 0;
    	}
    	// user statistics
    	$this->db->where('created>', $timestamp);
    	$this->db->where('type', 'user');
    	$this->db->where('deleted', 0);
		$this->db->order_by("id", "desc");
		$result = $this->db->get('tbl_user')->result_array();
		for ($i=0; $i < count($result); $i++) { 
			if ($result[$i]['id'] == 1) {
				continue;
			}
			$result[$i]['photo'] = base_url().'uploadImages/user/'.$result[$i]['photo'];
			$country = $this->db->get_where('tbl_country', array('phonecode' => $result[$i]['country_code']))->result_array();
			$result[$i]['country_name'] = $country[0]['nicename'];
			$result[$i]['country_flag'] = base_url().'assets/images/flags/'.strtolower($country[0]['iso']).'.png';
			array_push($array, $result[$i]);
		}
		return $array;
   }
   function get_servicesByDay($day = "all")
   {
    	$array = array();
    	if ($day == "daily") {
	    	$timestamp =strtotime("today");
    	} else if ($day == "weekly") {
    		$timestamp =strtotime("Last Monday");
    	} else if ($day == "monthly") {
    		$timestamp =strtotime(date('Y-m-01 00:00:00'));
    	} else {
    		$timestamp = 0;
    	}
    	// user statistics
    	$this->db->where('created>', $timestamp);
    	$this->db->where('deleted', 0);
		$this->db->order_by("id", "desc");
		$array = $this->db->get('tbl_service')->result_array();
		return $array;
   }
   function get_servicesById_Featured_Day($id, $featured, $day = "all")
   {
    	$array = array();
    	if ($day == "daily") {
	    	$timestamp =strtotime("today");
    	} else if ($day == "weekly") {
    		$timestamp =strtotime("Last Monday");
    	} else if ($day == "monthly") {
    		$timestamp =strtotime(date('Y-m-01 00:00:00'));
    	} else {
    		$timestamp = 0;
    	}
    	// user statistics

    	$this->db->where('created>', $timestamp);
    	if ($id > 0) {
			$this->db->where('creator_id', $id);
    	}
    	if ($featured == 1) {
	    	$this->db->where('featured', $featured);
    	}
    	$this->db->where('deleted', 0);
		$this->db->order_by("id", "desc");
		$array = $this->db->get('tbl_service')->result_array();
		for ($i=0; $i < count($array); $i++) { 
			$array[$i]['image'] = base_url().'uploadImages/service/'.$array[$i]['image'];
			$result = $this->db->get_where('tbl_user', array('id' => $array[$i]['creator_id']))->result_array();
			$array[$i]['creator'] = $result[0]['username'];
			$result = $this->db->get_where('tbl_big_category', array('id' => $array[$i]['big_category_id']))->result_array();
			$array[$i]['big_category'] = $result[0]['name'];
			$result = $this->db->get_where('tbl_sub_category', array('id' => $array[$i]['sub_category_id']))->result_array();
			$array[$i]['sub_category'] = $result[0]['name'];

			if ($array[$i]['created'] == 0) {
				$array[$i]['created'] = "";
			} else {
				$array[$i]['created'] = date("Y/m/d \<\b\\r\> h/i/s A", $array[$i]['created']);
			}
			if ($array[$i]['updated'] == 0) {
				$array[$i]['updated'] = "";
			} else {
				$array[$i]['updated'] = date("Y/m/d \<\b\\r\> h/i/s A", $array[$i]['updated']);
			}
		}
		return $array;
   }
   // --------------------------------------------------------------------------------------------------------------
	function get_members($type, &$array)
	{
		$array = array();
		$result = $this->db->get_where('tbl_user', array('type' => $type, 'deleted' => 0))->result_array();
		for ($i=0; $i < count($result); $i++) { 
			if ($result[$i]['id'] == 1) {
				continue;
			}
			$result[$i]['photo'] = base_url().'uploadImages/user/'.$result[$i]['photo'];
			$country = $this->db->get_where('tbl_country', array('phonecode' => $result[$i]['country_code']))->result_array();
			$result[$i]['country_name'] = $country[0]['nicename'];
			$result[$i]['country_flag'] = base_url().'assets/images/flags/'.strtolower($country[0]['iso']).'.png';
			array_push($array, $result[$i]);
		}
		return 200;
	}
	function get_userById($id, &$array)
	{
		$result = $this->db->get_where('tbl_user', array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$array = $result[0];
		$array['photo'] = $array['photo'];
		return 200;
	}	
	function getAllCountries(&$array)
	{
		$array = $this->db->get('tbl_country')->result_array();
		return $array;
	}
	function get_Allmembers($my_id, $my_type, $my_code, &$array)
	{
		$array = array();
		$result = $this->db->get_where('tbl_user', array('deleted' => 0))->result_array();
		array_push($array, array('id' => 0, 'username' => 'ALL', 'type' => 'public'));
		for ($i=0; $i < count($result); $i++) { 
			if ($my_id == $result[$i]['id']) {
				continue;
			}
			if ($my_type == 'operator' && $result[$i]['type'] == 'user' && $my_code != $result[$i]['country_code']) {
				continue;
			}
			if ($my_type == 'operator' && $result[$i]['type'] == 'operator') {
				continue;
			}
			$item['id'] = $result[$i]['id'];
			$item['username'] = $result[$i]['username'];
			$item['type'] = $result[$i]['type'];;
			array_push($array, $item);
		}
		return 200;
	}
	function change_status($table, $id, $status)
	{
		$result = $this->db->get_where($table, array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$this->db->where('id', $id);
		$this->db->update($table, array('status' => $status));
		return 200;
	}
	function delete_item($table, $id)
	{
		$result = $this->db->get_where($table, array('id' => $id, 'deleted' => 0))->result_array();
		if (count($result) == 0) {
			return 400;
		}
		$this->db->where('id', $id);
		$this->db->update($table, array('deleted' => 1));
		return 200;
	}
	function update_profile(&$id, $username, $email, $password, $code, $number,$photo ,$user_type , $page_type, &$error)
	{
		$result = $this->db->get_where('tbl_user', array('email' => $email, 'deleted' => 0))->result_array();
		if (count($result) > 0) {
			if ($page_type == 'new') {
				$error = 'Email already exists';
				return 400;
			}
			if ($result[0]['id'] != $id) {
				$error = 'Email already exists';
				return 400;
			}
		}
		if ($page_type == 'edit') {
			$this->db->where('id', $id);
			$this->db->update('tbl_user', array('username' => $username, 'email' => $email, 'password' => $password, 'country_code' =>$code, 'number' => $number, 'photo' => $photo));
			$error = 'Successfully updated';
		} else {
			$this->db->insert('tbl_user', array('type' => $user_type, 'username' => $username, 'email' => $email, 'password' => $password, 'country_code' =>$code, 'number' => $number, 'photo' => $photo, 'status' => 'active'));
			$id = $this->db->insert_id();
			$error = 'Successfully added';
		}
		
		return 200;
	}

	function get_IdByEmail($email, &$id)
	{
		$query = $this->db->get_where('tbl_user', array('email' => $email, 'deleted' => 0));
		$result = $query->result_array();
		if (count($result) > 0) {
			$id = $result[0]['id'];
			return 200;
		}
		return 400;
	}








































	

	// function chage_status($table, $id, $status)
	// {
	// 	$query = $this->db->get_where($table, array('id' => $id));
	// 	$result = $query->result_array();
	// 	if (count($result) == 0) {
	// 		return 400;
	// 	}

	// 	$this->db->where('id', $id);
	// 	$this->db->update($table, array('status' => $status));
	// 	return 200;
	// }

	// function get_EmailById($id, &$email)
	// {
	// 	$this->db->where("`status`!='delete' AND `id`='".$id."'");
	// 	$query = $this->db->get('tbl_user');
	// 	$result = $query->result_array();
	// 	if (count($result) > 0) {
	// 		$email = $result[0]['email'];
	// 		return 200;
	// 	}
	// 	return 400;
	// }

}

?>